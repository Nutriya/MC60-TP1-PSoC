#include "BME280.h"
#include "project.h"
#include <stdint.h>

/*Fonction    : BME280_WriteReg
**but         : Ecrire une commande dans un registre
**entrée      : WriteAddr, WriteData
**sortie      : None
**Usage       : BME280_WriteReg(WriteAddr, WriteData);
*/
void BME280_WriteReg( uint8 WriteAddr, uint8 WriteData )
{
    uint8 writeBuf[2]={0};
    writeBuf[0]=WriteAddr;
    writeBuf[1]=WriteData;
    I2C_I2CMasterWriteBuf(ADR_SLAVE, (uint8 *)&writeBuf, sizeof(writeBuf), I2C_I2C_MODE_COMPLETE_XFER);
    while((I2C_I2CMasterStatus()& I2C_I2C_MSTAT_WR_CMPLT)==0) {}
    I2C_I2CMasterClearStatus(); 
}

/*Fonction  : BME280_ReadReg
**but       : Lire les informations d'un registre
**entrée    : ReadAddr
**sortie    : ReadData
**Usage     : ReadData = BME280_ReadReg(ReadAddr);
*/

uint8_t BME280_ReadReg( uint8_t ReadAddr )
{
    uint8 ReadData;
   /* =======================================  
    code à compléter ici
    =========================================*/
    
    return ReadData;
}


/* =========================================================
 ** Routines établies à partir de la datasheet du composant
* ==========================================================
*/

// Returns temperature in DegC, resolution is 0.01 DegC. Output value of “5123” equals 51.23 DegC.
// t_fine carries fine temperature as global value
int32_t BME280_compensate_T_int32(int32_t adc_T)
{
int32_t var1, var2, T;
var1 = ((((adc_T>>3)-((int32_t)dig_T1<<1))) * ((int32_t)dig_T2)) >> 11;
var2 = (((((adc_T>>4)-((int32_t)dig_T1))*((adc_T>>4)-((int32_t)dig_T1))) >> 12)*((int32_t)dig_T3)) >> 14;
t_fine = var1 + var2;
T = (t_fine * 5 + 128) >> 8;
return T;
}

// Returns pressure in Pa as unsigned 32 bit integer in Q24.8 format (24 integer bits and 8 fractional bits).
// Output value of “24674867” represents 24674867/256 = 96386.2 Pa = 963.862 hPa
uint32_t BME280_compensate_P_int64(int32_t adc_P)
{
int64_t var1, var2, p;
var1 = ((int64_t)t_fine)-128000;
var2 = var1 * var1 * (int64_t)dig_P6;
var2 = var2 + ((var1*(int64_t)dig_P5)<<17);
var2 = var2 + (((int64_t)dig_P4)<<35);
var1 = ((var1 * var1 * (int64_t)dig_P3)>>8) + ((var1 * (int64_t)dig_P2)<<12);
var1 = (((((int64_t)1)<<47)+var1))*((int64_t)dig_P1)>>33;
if (var1 == 0) return 0; // avoid exception caused by division by zero
p = 1048576-adc_P;
p = (((p<<31)-var2)*3125)/var1;
var1 = (((int64_t)dig_P9) * (p>>13) * (p>>13)) >> 25;
var2 = (((int64_t)dig_P8) * p) >> 19;
p = ((p + var1 + var2) >> 8) + (((int64_t)dig_P7)<<4);
p=p>>8;
return (uint32_t)p;
}


double BME280_compensate_P_double(int32_t adc_P)
{
    double var1,var2,p;
    var1=((double)t_fine/2.0)-64000.0;
    var2=var1*var1*((double)dig_P6)/32768.0;
    var2=var2+var1*((double)dig_P5)*2.0;
    var1=(((double)dig_P3)*var1*var1/524288.0+((double)dig_P2)*var1)/524288.0;
    var1=(1.0+var1/32768.0)*((double)dig_P1);
    p=1048576.0-(double)adc_P;
    p=(p-(var2/4096.0))*6250.0/var1;
    var1=((double)dig_P9)*p*p/2147483648.0;
    var2=p*((double)dig_P8)/32768.0;
    p=p+(var1+var2+((double)dig_P7))/16.0;
    return p;
}

/* [] END OF FILE */
